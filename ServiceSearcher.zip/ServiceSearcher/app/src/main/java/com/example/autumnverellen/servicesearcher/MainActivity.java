package com.example.autumnverellen.servicesearcher;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import android.view.View;
import android.content.Intent;

import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class MainActivity extends AppCompatActivity {
    EditText editTextName;
    EditText editTextPrice;
    Button buttonAddProduct;
    ListView listViewProducts;
    FirebaseDatabase dS = FirebaseDatabase.getInstance();
    String[] users;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_activity);

        buttonLogIn = (Button) findViewById(R.id.buttonLogIn);
        buttonNewUser = (Button) findViewById(R.id.buttonNewUser);
        buttonUserType = (RadioGroup) findViewById(R.id.buttonUserType);
        buttonSubmitLogIn = (Button) findViewById(R.id.buttonSubmitLogIn);
        buttonSubmitNewUser = (Button) findViewById(R.id.buttonSubmitNewUser);

        editTextLogInUser = (EditText) findViewById(R.id.editTextLogInUser);
        editTextLogInPass = (EditText) findViewById(R.id.editTextLogInPass);
        editTextNewUser = (EditText) findViewById(R.id.editTextNewUser);
        editTextNewPass = (EditText) findViewById(R.id.editTextNewPass);

        buttonLogIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                editTextLogInUser.setVisibility(View.VISIBLE);
                editTextLogInPass.setVisibility(View.VISIBLE);
                buttonSubmitLogIn.setVisibility(View.VISIBLE);

                String username = editTextLogInUser.getText().toString();
                String password = editTextLogInPass.getText().toString();

                if (username.length() != 0 && password.length() != 0){
                    if (userExists(username, password) == true){
                        Intent logIn = new Intent(getApplicationContext(), AddServices.class);
                        StartActivity(logIn);
                        setContentView(R.layout.add_services);
                    } else {
                        editTextNewUser.setVisibility(View.VISIBLE);
                        editTextNewPass.setVisibility(View.VISIBLE);

                        String newuser = editTextNewUser.getText().toString();
                        String newpass = editTextNewUser.getText().toString();
                    }
                } else {
                    editTextLogInUser.getText().clear();
                    editTextLogInPass.getText().clear();
                }



                //logIn.putExtra(username, password)
            }
        });
        buttonNewUser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                editTextNewUser.setVisibility(View.VISIBLE);
                editTextNewPass.setVisibility(View.VISIBLE);
                buttonUserType.setVisibility(View.VISIBLE);
                buttonSubmitNewUser.setVisibility(View.VISIBLE);

                String newuser = editTextNewUser.getText().toString();
                String newpass = editTextNewUser.getText().toString();

                if (userExists(username, password) == true){
                    Intent logIn = new Intent(getApplicationContext(), AddServices.class);
                    StartActivity(logIn);
                    setContentView(R.layout.add_services);
                }
            }
        });
    }

    public boolean UserExists(String username, String password){
        for (int i = 0; i < users.length; i++){
            if (i[0].equals(username)){
                if (i[1].equals(password)){
                    return true;
                }
            }
        }
        return false;
    }
}
